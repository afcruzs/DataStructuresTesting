package unal.datastructures.taller2;
import java.util.*;
import unal.datastructures.*;
import unal.datastructures.ArrayLinearList;
import unal.datastructures.Chain;
import unal.datastructures.LinearList;
import unal.datastructures.MaxHeap;

public class KSumPair<T> {

	protected int nuno; 
	
	public KSumPair(){
		nuno = 0;
	}
	
	public int solve(LinearList<Integer> A, LinearList<Integer> B, int k){
		
		int especia =(A.size()*A.size()-1);
		MaxHeap<Integer> salvenme=new MaxHeap<>(especia);
				
		if(A.size() != B.size())
			throw new IllegalArgumentException ("Las dos listas deben tener el mismo tamaño");
			
		if (k == 0) 
			return (A.get(0)+ B.get(0));
	
		k++;
		
		for(int i=0;i<B.size();i++){
			if (nuno==k) break;
				for(int j=0;j<B.size();j++){
					if (nuno==k) break;
					
					if(salvenme.size() < especia-1){
						salvenme.put(A.get(i)+ B.get(j));
					}else{
						nuno++;
						salvenme.removeMax();
						salvenme.put(A.get(i)+ B.get(j));
					}												
				}
			}
		nuno++;
		while (nuno != k ){ 
				salvenme.removeMax();
			nuno++;
		}
		return salvenme.getMax();
	}
	
	public static void main (String[] args){
		
		ArrayLinearList<Integer> liston1 = new ArrayLinearList<>( );
		ArrayLinearList<Integer> monio2 = new ArrayLinearList<>( );
		KSumPair<Integer> pruebita = new KSumPair<>();
		
		liston1.add( 0, new Integer( 13 ) );
		liston1.add( 1, new Integer( 4 ) );
		liston1.add( 2, new Integer( 2) );	
		
		monio2.add( 0, new Integer( 15 ) );
		monio2.add( 1, new Integer( 8 ) );
		monio2.add( 2, new Integer( 1 ) );	

		System.out.println(pruebita.solve(liston1,monio2,8));
	} 
}
package unal.datastructures;
import java.util.*;

public class LinearListPriorityQueue<T extends Comparable<? super T>> implements MaxPriorityQueue<T>{
	ArrayLinearList<T> pq;
	
	public LinearListPriorityQueue(int initialCapacity){
		pq= new ArrayLinearList<>(initialCapacity);
	}
	
	public LinearListPriorityQueue(){
		this(10);
	}
	
	public boolean isEmpty( ){
      return pq.isEmpty();
	}
   
	public int size(){
		int ss=pq.size();
		return (ss==0) ? 0 : ss-1;
	}
	
	public T getMax( ){
		return ( pq.size() == 0 ) ? null : pq.get(1);
   }
	
	@SuppressWarnings( "unchecked" )
	public void put( T theO ){
		int i=1;
		if(pq.isEmpty())
			pq.add(0, theO);			
		while(i < pq.size() && pq.get(i).compareTo(theO)>0 )
			i++;
		pq.add(i, theO);
	}
	
	public T removeMax( ){
		T are= pq.remove(1);
		return are;
	}
   
	
	public String toString( ){
		StringBuilder s = new StringBuilder( );
		s.append( "[ " );
		if( pq.size() > 0 ){  
			s.append( Objects.toString( pq.get( 1 )));
        for( int i = 2; i < pq.size(); i++ )
            s.append( ", " + Objects.toString( pq.get( i )));
		}
		s.append( " ]" );
		return new String( s );
	}
   
	public static void main(String[] args){
		LinearListPriorityQueue<Integer> llpq= new LinearListPriorityQueue<>(50);
		MaxHeap<Integer> mh= new MaxHeap<>(50);
		
		for(int j=0; j<10;j++){
		System.out.println(j + "________");
		// fase 1
		Random rd = new Random( );
		long time= System.currentTimeMillis();
		for(int i=0;i<100000;i++){
			int a=rd.nextInt(9000);
			llpq.put(a);
		}
		time=System.currentTimeMillis()-time;
		System.out.println("El tiempo en micro segundos fue: " + time);
		
		time= System.currentTimeMillis();
		for(int i=0;i<100000;i++){
			int a=rd.nextInt(9000);
			mh.put(a);
		}
		time=System.currentTimeMillis()-time;
		System.out.println("El tiempo en micro segundos fue: " + time);
		
		// fase 2
		time=System.currentTimeMillis()-time;
		for(int i=0; i<50000;i++){
			llpq.removeMax();
			llpq.getMax();
		}
		time=System.currentTimeMillis()-time;
		System.out.println("El tiempo en micro segundos fue: " + time);
		
		
		time=System.currentTimeMillis()-time;
		for(int i=0; i<50000;i++){
			mh.removeMax();
			mh.getMax();
		}
		time=System.currentTimeMillis()-time;
		System.out.println("El tiempo en micro segundos fue: " + time);
		}
		
	}

}
package unal.datastructures.taller2;
import java.util.*;

public class MyLBT<T> extends LinkedBinaryTree<T>{
	static int dia=0;
	
	public static void main(String[] args){
		MyLBT<String> a = new MyLBT<>( );
		MyLBT<String> r = new MyLBT<>( );
		MyLBT<String> s = new MyLBT<>( );
		MyLBT<String> t = new MyLBT<>( );
		MyLBT<String> u = new MyLBT<>( );
		MyLBT<String> v = new MyLBT<>( );
	  
		r.makeTree( "once", a, a );
		s.makeTree( "doce", a, a );
		t.makeTree( "ocho", r, s );
		r.makeTree( "trece", a, a );
		s.makeTree( "nueve", a, r );
		r.makeTree( "cuatro", t, s );
		s.makeTree( "cinco", a, a );
		t.makeTree( "dos", r, s );
		r.makeTree( "veinte", a, a );
		s.makeTree( "diseis", r, a );
		r.makeTree( "disiete", a, a );
		u.makeTree( "cato", s, r );
		s.makeTree( "diocho", a, a );
		r.makeTree( "dinueve", a, a );
		v.makeTree( "quin", s, r );
		s.makeTree( "diez", u, v );
		u.makeTree( "seis", s, a );
		v.makeTree( "siete", a, a );
		s.makeTree( "tres", u, v );
		u.makeTree( "uno", t, s );
		u.levelOrderOutput();
		System.out.println();
		System.out.println("brother of siete: " + u.brother("siete"));
		u.preOrderOutput();
		System.out.println();
		u.inOrderOutput();
		System.out.println();
		u.postOrderOutput();
		System.out.println();
		System.out.println("diameter: " + u.diameter( ));
		u.shuffle();
		System.out.println("shuffle: "); 
		u.levelOrderOutput();
		System.out.println();
		
		MyLBT<Integer> aa = new MyLBT<>( );
		MyLBT<Integer> f = new MyLBT<>( );
		MyLBT<Integer> g = new MyLBT<>( );
		MyLBT<Integer> h = new MyLBT<>( );
		MyLBT<Integer> i = new MyLBT<>( );
		MyLBT<Integer> j = new MyLBT<>( );
		f.makeTree( 11, aa, aa );
		g.makeTree( 12, aa, aa );
		h.makeTree( 8, f, g );
		f.makeTree( 13, aa, aa );
		g.makeTree( 9, aa, f );
		f.makeTree( 4, h, g );
		g.makeTree( 5, aa, aa );
		h.makeTree( 2, f, g );
		f.makeTree( 20, aa, aa );
		g.makeTree( 16, f, aa );
		f.makeTree( 17, aa, aa );
		i.makeTree( 14, g, f );
		g.makeTree( 18, aa, aa );
		f.makeTree( 19, aa, aa );
		j.makeTree( 15, g, f );
		g.makeTree( 10, i, j );
		i.makeTree( 6, g, aa );
		j.makeTree( 7, aa, aa );
		g.makeTree( 3, i, j );
		i.makeTree( 1, h, g );
		i.levelOrderOutput();
		System.out.println();
		System.out.println("brother of disiete: " + i.brother(17));
		i.preOrderOutput();
		System.out.println();
		i.inOrderOutput();
		System.out.println();
		i.postOrderOutput();
		System.out.println();
		System.out.println("diameter: " + i.diameter( ));
		i.shuffle();
		System.out.println("shuffle: "); 
		i.levelOrderOutput();
	
	
	}

	//brother(T x): retorna el hermano del elemento x,
	//retorna null si dicho elemento no existe.
	
	public T brother(T ni){
		ArrayQueue<BinaryTreeNode<T>> q=new ArrayQueue<>();
		BinaryTreeNode<T> t= root;
		while(t!=null){
			if (t.leftChild != null)
				if(ni.equals(t.leftChild.element))
					if (t.rightChild != null )
						return t.rightChild.element;
				q.put( t.leftChild );
			if (t.rightChild != null)
				if(ni.equals(t.rightChild.element))
					if(t.leftChild != null)
						return t.leftChild.element;					
				q.put( t.rightChild );
			t = ( BinaryTreeNode<T> ) q.remove( );
		}
		return null;
	}
	
	
	//shuffle(): cambia los nodos pero mantiene la estructura original del arbol.
	@SuppressWarnings( "unchecked" )
	public void shuffle(){
		BinaryTreeNode<T> t = root;
		LinkedQueue < BinaryTreeNode <T> > q = new LinkedQueue<>( );
		int rs = size();
		T[] m = (T[]) new Object[rs];
		Random rd = new Random( );
		int index = 1;
		m[0] = root.element;
		q.put( root );
		while( !q.isEmpty() ){	
			t = q.remove();
			if( t == null ) continue;
			if( t.leftChild != null ){
				m[index++] = t.leftChild.element;
			}
			if( t.rightChild != null ){
				m[index++] = t.rightChild.element;
			}
			q.put( t.leftChild );
			q.put( t.rightChild );	
		}
		for( int i = 0, a = 0; i < rs/2; i++){
			T tmp = m[i];
			a = (int)( rd.nextDouble() * ( rs ) );
			m[i] = m[a];
			m[a] = tmp;
		}
		index = 1;
		root.element = m[ 0 ];
		q.put( root );
		while( !q.isEmpty() ){
			t = q.remove();
			if( t == null ) continue;
			if( t.leftChild != null ){
				t.leftChild.element = m[index];
				index++;
			}
			if( t.rightChild != null ){
				t.rightChild.element = m[index];
				index++;
			}
			q.put( t.leftChild );
			q.put( t.rightChild );
		}
	}
	
	
	
	
	//implementa los recorridos preOrderOutput, inOrderOutput posOrderOutput
	//de manera iterativa(no recursiva)
	
	@Override
	public void preOrderOutput(){
		LinkedStack<BinaryTreeNode<T>> q=new LinkedStack<>();
		BinaryTreeNode<T> t= root;
		q.push( t );
		System.out.println("preOrder:");
		for(int i=0; i<size();i++){
			System.out.print(t.element + " ");
			if (t.rightChild != null)
				q.push( t.rightChild );
			if (t.leftChild != null)
				q.push( t.leftChild );
			t = ( BinaryTreeNode<T> ) q.pop( );
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void inOrderOutput(){
		BinaryTreeNode<T> t = this.root;
		ArrayStack<BinaryTreeNode> q = new ArrayStack<>();
		q.push(t);
		System.out.println("inOrder:");
		int iii=this.size();
		while(!q.isEmpty() && iii>0){
			if((t.leftChild != null)){
				q.push(t.leftChild);
				t = t.leftChild;
			}
			else {
				t = q.pop();
				System.out.print(t.element + " ");
				iii--;
				if(t.rightChild != null){
					q.push(t.rightChild);
					t = t.rightChild;
				}
			}
		}
	}

	
	@Override
	public void postOrderOutput(){		
		LinkedStack<T> cute = new LinkedStack<>(); 
		LinkedStack<BinaryTreeNode<T>> q = new LinkedStack<>( );
		BinaryTreeNode<T> t = root;
		System.out.println("postOrder:");
		for(int i=0; i < size();i++){
			cute.push( t.element);
			if(t.leftChild != null)
				q.push( t.leftChild );
			if(t.rightChild != null)
				q.push( t.rightChild );
			if(!q.isEmpty()) 
				t = q.pop( );
		}
		while(!cute.isEmpty())
			System.out.print(cute.pop() + " ");
	}
	
	//int diameter(): retorna el diametro del arbol binario.
	public int diameter( ){
		dia=0;
		theD( root );
		return dia;
	}

	static <T> int theD( BinaryTreeNode<T> t ){
		if( t == null )
			return 0;
		int hl = theD( t.leftChild );  
		int hr = theD( t.rightChild ); 
		if( (hl + hr + 1) > dia )
			dia= hl + hr + 1;
		if(hl > hr)
			return hl+1;
		else
			return hr+1;
	}
	
}




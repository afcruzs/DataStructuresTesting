/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package unal.datastructures.taller2;

import java.awt.geom.CubicCurve2D;
import unal.datastructures.*;
import java.util.*;        
public class KSumPair {
    
    public static int solve(LinearList<Integer> a, LinearList<Integer> b , int k){
        MaxHeap<Pareja> p = new MaxHeap<>();
        LinearList<Pareja> parejas = new ArrayLinearList<>();
        int i=0;
        int j=0;
        Pareja p1 = new Pareja(a.get(i), b.get(j));
        
         int l=0;
        int m=0;
        int counter =0;
       
        Pareja p2 = new Pareja(a.get(++l), b.get(m));
        try{
        while(i<a.size() && m<b.size() && counter<=k){
            System.out.println("pareja 1: "+ p1);
            System.out.println("pareja 2: "+ p2);
            if(p1.compareTo(p2)>0){
                System.out.println("p1>p2");
                if(parejas.indexOf(p1)==-1){
                    parejas.add(parejas.size(), p1);
                p.put(p1);
                }
                else{
                    counter--;
                }
                
                if(j<b.size()-1){
                    
                    p1 = new Pareja(a.get(i), b.get(++j));
                    System.out.println("i = " + i +"  ,j= " + j);
                }
                else{
                    j=0;
                    p1 = new Pareja(a.get(++i), b.get(j));
                    System.out.println("i = " + i +"  ,j= " + j);
                }
                
                
            }
            else{
                
                System.out.println("caso contrario");
                if(parejas.indexOf(p2)==-1) {   
                    parejas.add(parejas.size(), p2);
                p.put(p2);
                }
                else{
                    counter--;
                }
                
                if(l<a.size()-1){
                    p2 = new Pareja(a.get(++l),b.get(m));
                    System.out.println("l = " + l +"  ,m= " + m);
                }
                else{
                    l=0;
                    p2 = new Pareja(a.get(l),b.get(++m));
                    System.out.println("l = " + l +"  ,m= " + m);
                }
            }
            System.out.println("iteracion");
            counter++;
            System.out.println("counter: " + counter);
        }
        }
        catch(Exception e){
           e.printStackTrace();
        }
        
        
        System.out.println("fin ciclo");
        while(p.size()>1){
            p.removeMax();
            
        }
        return p.getMax().elem1 + p.getMax().elm2;
     }
    
    public static void main(String[] args){
        LinearList<Integer> l1 = new ArrayLinearList<>();
        LinearList<Integer> l2 = new ArrayLinearList<>();
        l1.add(0, 13);
        l1.add(1, 4);
        l1.add(2, 2);
        l2.add(0, 15);
        l2.add(1, 8);
        l2.add(2, 1);
        
        int j = solve(l1,l2,3);
        System.out.println("suma is:" + j);
    
    }
}

class Pareja implements Comparable<Pareja>{
    int elem1;
    int elm2;

    public Pareja(int elem1, int elm2) {
        this.elem1 = elem1;
        this.elm2 = elm2;
    }

    
    public int compareTo(Pareja o) {
         return (this.elem1 + this.elm2) - (o.elem1 + o.elm2);
    }
    @Override
    public String toString(){
        return "ele1: " + elem1 +" elem2: " + elm2;
    }
    
    @Override
     public boolean equals( Object o )
   {
      if( o == null ) return false;
      if( o == this ) return true;
      if( ! ( o instanceof Pareja ) ) return false;
      return (this.elem1 == ((Pareja) o).elem1)  &&  (this.elm2 == ((Pareja) o).elm2);
   }
    
    
}

package unal.datastructures.Taller2;

import java.util.Random;

import javax.lang.model.element.Element;


public class MyLBT<T  extends Comparable<T>> extends LinkedBinaryTree<T>{
	public T brother(T x){
	    ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
	     BinaryTreeNode<T> t = root;
		  
	     while(t!=null){
			if (t.leftChild != null)
				if(x.equals(t.leftChild.element)){
					if(t.rightChild != null){
						return t.rightChild.element;
					}
				return null;
				}
			
			if (t.rightChild != null)
			    if(x.equals(t.rightChild.element)){
			    	if(t.leftChild != null){
			    		return t.leftChild.element;
			    	}
			    	return null;
				}
	        
			if( t.leftChild != null )
	            q.put( t.leftChild );
	         if( t.rightChild != null )
	            q.put( t.rightChild );

	         t = ( BinaryTreeNode<T> ) q.remove( );

		  }
		return null;
	}
	
	public T[] barajar(T[] baraja, int tam){
		Random joker = new Random();
		int index = 0;
		T temp;
		for(int i = 0; i<tam; i++){
			index = joker.nextInt(i+1);
			temp = baraja[index];
			baraja[index] = baraja[i];
			baraja[i] = temp;
		}
		return baraja;
	}
	
	public void shuffle(){
		 ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
	      BinaryTreeNode<T> t = root;
	      T arbol[];
	      arbol = ( T[] ) new Comparable[20];
	      int record = 0;
	      while( t != null )
	      {
	    	  if( record == arbol.length - 1 ){
	    		   T[] old = arbol;
	    		   arbol = ( T[] ) new Comparable[ 2 * arbol.length ];
	    		   for( int i = 0; i < old.length; i++ )
	    		   arbol[ i ] = old[ i ];
	    	    }
	    	  
	         arbol[record] = t.element;
	    	  

	         // put t's children on queue
	         if( t.leftChild != null )
	            q.put( t.leftChild );
	         if( t.rightChild != null )
	            q.put( t.rightChild );

	         // get next node to visit
	         t = ( BinaryTreeNode<T> ) q.remove( );
	         record++;
	      }
	      arbol = barajar(arbol, record);
	      
	      ArrayQueue<BinaryTreeNode<T>> k = new ArrayQueue<>( );
	      record = 0;
	      t = root;
	      while( t != null )
	      {  
	         t.element = arbol[record];

	         // put t's children on queue
	         if( t.leftChild != null )
	            k.put( t.leftChild );
	         if( t.rightChild != null )
	            k.put( t.rightChild );

	         // get next node to visit
	         t = ( BinaryTreeNode<T> ) k.remove( );
	         record++;
	      }
	}
	
	/*Override
	public void preOrderOutput(){
		BinaryTreeNode<T> t = root;
		ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
		boolean pila;
		
		while(t != null){
			q.put(t);
			//t = q.remove(0);
			//System.out.print(t.element);
			t = t.leftChild;
		}
		do{
			if(!q.isEmpty()){
				t = q.remove();
				System.out.print(t.element);
				}else{t = null;}
			
			if(t != null && t.rightChild != null){
				t = t.rightChild;
				q.put(t);
				while(t != null && t.leftChild != null){
					t = t.leftChild;
					q.put(t);
				}
			}
			
			pila = q.isEmpty();
		}while(pila =! true || t != null);
	}*/
	
	@Override
	public void preOrderOutput(){
		BinaryTreeNode<T> t = root;
		ArrayStack<BinaryTreeNode<T>> q =  new ArrayStack<>();
		boolean pila;
		
		while(t != null){
			System.out.print(t.element);
			//q.push(t);
			t = t.leftChild;
		}
		t = root;
		while(t != null){
			if(t != null && t.rightChild != null){
				t = t.rightChild;
				q.push(t);
				while(t != null && t.leftChild != null){
					t = t.leftChild;
					q.push(t);
				}
			}
			t = t.rightChild;
		}
		
		do{
			if(!q.isEmpty()){
				t = q.pop();
				System.out.print(t.element);
				}else{t = null;}
			
			pila = q.isEmpty();
		}while(pila =! true || t != null);
		
	}
	
	@Override
	public void inOrderOutput(){
		BinaryTreeNode<T> t = root;
		ArrayLinearList<BinaryTreeNode<T>> q = new ArrayLinearList<>( );
		boolean pila;
		
		while(t != null){
			q.add(0, t);
			t = t.leftChild;
		}
		do{
			
			if(t != null && t.rightChild != null){
				t = t.rightChild;
				q.add(0, t);
				while(t != null && t.leftChild != null){
					t = t.leftChild;
					q.add(0, t);
				}
			}
			
			if(!q.isEmpty()){
				t = q.remove(0);
				System.out.print(t.element);
				}else{t = null;}
			
			pila = q.isEmpty();
		}while(pila =! true || t != null);
	}
	
	@Override
	public void postOrderOutput(){
	
	}
	
	public int diameter(){
		return 0;
	}
	
	public BinaryTreeNode<T> father (T leaf){
	    ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
	      BinaryTreeNode<T> t = root;
		  while(t!=null){
			if (t.leftChild != null)
				if(leaf.equals(t.leftChild.element))
				return t;
			if (t.rightChild != null)
			    if(leaf.equals(t.rightChild.element))
				return t;
	         if( t.leftChild != null )
	            q.put( t.leftChild );
	         if( t.rightChild != null )
	            q.put( t.rightChild );

	         t = ( BinaryTreeNode<T> ) q.remove( );
			 
	      }
		  return null;
	   }

	public static void main(String[] args) {
		MyLBT<Character> a = new MyLBT<>( );
		MyLBT<Character> x = new MyLBT<>( );
		MyLBT<Character> y = new MyLBT<>( );
		MyLBT<Character> z = new MyLBT<>( );
		MyLBT<Character> w = new MyLBT<>( );
		MyLBT<Character> v = new MyLBT<>( );
			
		y.makeTree( 'D', a, a );
		x.makeTree( 'E', a, a );
		z.makeTree( 'R', y, x );
		y.makeTree( 'Z', a, a );
		x.makeTree( 'G', a, a );
		w.makeTree( 'A', y, x );
		y.makeTree( 'D', z, w );
		z.makeTree( 'O', a, a );
		x.makeTree( 'N', a, a );
		w.makeTree( 'R', z, x );
		z.makeTree( 'Z', a, a );
		x.makeTree( 'A', a, a );
		v.makeTree( 'D', z, x );
		z.makeTree( 'Y', w, v );
		x.makeTree( 'R', y, z );
		y.makeTree( 'L', a, a );
		z.makeTree( 'E', a, a );
		w.makeTree( 'O', y, z );
		y.makeTree( 'Z', a, a );
		z.makeTree( 'M', y, a ); //
		y.makeTree( 'G', w, z );
		z.makeTree( 'E', a, a );
		w.makeTree( 'N', a, a );
		v.makeTree( 'E', z, w );
		z.makeTree( 'E', y, v );
		w.makeTree( 'F', x, z );
		
		//1.1
		w.levelOrderOutput( );
		System.out.println( );
		System.out.println("brother the O is: " + w.brother('O')); //M
		System.out.println("brother the N is: " + w.brother('N')); //E
		
		//1.2
		w.shuffle();
		w.levelOrderOutput( );
		System.out.println( );
		
		//1.3
		y.makeTree( 'D', a, a );
		x.makeTree( 'E', a, a );
		z.makeTree( 'B', y, x );
		y.makeTree( 'F', a, a );
		x.makeTree( 'C', y, a );
		y.makeTree( 'A', z, x );
		
		
		y.inOrderOutput( );			// DBEAFC
		System.out.println( );
		y.preOrderOutput( );		//ABDECF
		System.out.println( );

	}

}

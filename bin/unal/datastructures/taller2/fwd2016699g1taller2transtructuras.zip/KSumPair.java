package unal.datastructures.Taller2;

public class KSumPair{
	
	//Constructor
	public KSumPair(){}
	
	public static void main(String[] args){
		KSumPair XD = new KSumPair();
		ArrayLinearList<Integer> lista1 = new ArrayLinearList<>();
		ArrayLinearList<Integer> lista2 = new ArrayLinearList<>();	
		lista1.add( 0, 13 );
		lista1.add( 1, 4 );
		lista1.add( 2, 2 );
		lista2.add( 0, 15 );
		lista2.add( 1, 8 );
		lista2.add( 2, 1 );
		//Show Lists
		System.out.println( "+++++THE Kth LARGEST SUM+++++" );
		System.out.println( "List 1:" );
		System.out.println( lista1 );
		System.out.println( "\nList 2:" );
		System.out.println( lista2 +"\n");
		System.out.println(XD.solve(lista1,lista2,8));
	}
	
	//Method
	public int solve(LinearList<Integer> A, LinearList<Integer> B, int k){
		MaxHeap<Integer> aux = new MaxHeap<>();
		
		for( int i = 0 ; i < A.size( ) ; i++ ){
			for(int j = 0; j < B.size( ); j++ )
				aux.put(  A.get( i ) + B.get( j ) );
		}
		System.out.println("All possible sums: ");
		System.out.println(aux);
		System.out.println("\nThe firsts "+ (k - 1) +" elements ordered:");
		for(int i = 0 ; i < k ; i++){
			System.out.println(aux.getMax());
			aux.removeMax();
		}
		System.out.print("\nThe "+k+"th element is: ");
		return aux.removeMax();
	}
}
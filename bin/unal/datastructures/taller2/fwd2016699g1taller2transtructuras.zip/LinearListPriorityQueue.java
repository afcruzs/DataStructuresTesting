package unal.datastructures.taller2;

import java.util.Random;
import unal.datastructures.*;

public class LinearListPriorityQueue<T extends Comparable<? super T>> implements MaxPriorityQueue<T>
{
	ArrayLinearList<T> heap = new ArrayLinearList<>();
   //Chain<T> heap = new Chain<>();

	public boolean isEmpty( )
	{
		return heap.isEmpty();
	}

   public int size( )
   {
   	return heap.size();
   }

   public T getMax( )
   {
   	if (isEmpty())
      {
         return null;
      }

      else
      {
         return heap.get(0);
      }
   }

   public void put(T theObject )
   {
   	int index = 0;
      boolean stop = false;

   	while((index < heap.size())&& (stop != true))
   	{
   		if ((heap.get(index).compareTo(theObject)) > 0 )
         {
            index++;
         }

         else
         {
            stop = true;
         }
   	}

      heap.add(index, theObject);
   }

   public void put2(int index, T theObject )
   {
   	heap.add(index, theObject);
   }

   public T removeMax( )
   {
   	T maxRemoved = getMax();

      if (!isEmpty())
      {
         heap.remove(0);
      }

      return maxRemoved;      
   }

   public String toString()
   {
      return heap.toString();
   }

   public void adicionesInt ()
   {
      Random aleatorio = new Random();

      for (int i=0; i<100000; i++)
      {
         T elemento = (T)(Object)(int)(aleatorio.nextDouble() * 3000);
         
         //System.out.println("\n" + elemento);
         put(elemento);
      }
   }

   public void removeYGet ()
   {
      Random aleatorio = new Random();

      for (int i=0; i<50000; i++)
      {
         int elemento = (int)(aleatorio.nextDouble() * 2);
         
         if(elemento == 1)
         {
            System.out.println("remove:" + removeMax());
         }
         else
         {
            System.out.println("get:" + getMax());
         }
      }
   }

   public void adicionesInt (MaxHeap<T> mh)
   {
      Random aleatorio = new Random();

      for (int i=0; i<100000; i++)
      {
         T elemento = (T)(Object)(int)(aleatorio.nextDouble() * 3000);
         
         //System.out.println("\n" + elemento);
         mh.put(elemento);
      }
   }

   public void removeYGet (MaxHeap<T> mh)
   {
      Random aleatorio = new Random();

      for (int i=0; i<50000; i++)
      {
         int elemento = (int)(aleatorio.nextDouble() * 2);
         
         if(elemento == 1)
         {
            System.out.println("remove:" + mh.removeMax());
         }
         else
         {
            System.out.println("get:" + mh.getMax());
         }
      }
   }

   public static void main (String args[])
   {
   	LinearListPriorityQueue<Integer> llpq = new LinearListPriorityQueue<>();

      MaxHeap<Integer> mh = new MaxHeap<>();
      
      /**System.out.println(llpq);
  		System.out.println(llpq.isEmpty());
  		System.out.println(llpq.size());
  		System.out.println(llpq.getMax());
      System.out.println(llpq.removeMax());
     
      llpq.put(9);
      System.out.println(llpq);
      llpq.put(1);
      System.out.println(llpq);
      llpq.put(5);
      System.out.println(llpq);

      System.out.println(llpq.removeMax());
      System.out.println(llpq);
      System.out.println(llpq.getMax());*/

      /**long time = System.currentTimeMillis();
      System.out.println("\n" + llpq);
      llpq.adicionesInt();
      System.out.println("\n" + llpq);
      time = System.currentTimeMillis() - time;
      System.out.println("El  tiempo en   micro segundos fue:  " +   time);

      long time2 = System.currentTimeMillis();
      System.out.println("\n" + llpq);
      llpq.removeYGet();
      System.out.println("\n" + llpq);
      time2 = System.currentTimeMillis() - time2;
      System.out.println("El  tiempo en   micro segundos fue:  " +   time2);*/

      long time3 = System.currentTimeMillis();
      //System.out.println("\n" + mh);
      llpq.adicionesInt(mh);
      //System.out.println("\n" + mh);
      time3 = System.currentTimeMillis() - time3;
      System.out.println("El  tiempo en   micro segundos fue:  " +   time3);

      long time4 = System.currentTimeMillis();
      llpq.removeYGet(mh);
      time4 = System.currentTimeMillis() - time4;
      System.out.println("El  tiempo en   micro segundos fue:  " +   time4);
 	}
}
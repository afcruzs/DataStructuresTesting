package unal.datastructures.taller2;

import java.lang.*;
import unal.datastructures.*;

public class MyLBT<T> extends LinkedBinaryTree<T> {
	
	public MyLBT(){
		super();
	}
	
	public static void main(String[] args){
		MyLBT<Integer> a = new MyLBT<>();
		MyLBT<Integer> ja = new MyLBT<>();
		MyLBT<Integer> je = new MyLBT<>();
		MyLBT<Integer> ji = new MyLBT<>();
		MyLBT<Integer> jo = new MyLBT<>();
		MyLBT<Integer> ju = new MyLBT<>();
		MyLBT<Integer> ya = new MyLBT<>();
		
		MyLBT<String> x = new MyLBT<>();
		MyLBT<String> pa = new MyLBT<>();
		MyLBT<String> pe = new MyLBT<>();
		MyLBT<String> pi = new MyLBT<>();
		MyLBT<String> po = new MyLBT<>();
		MyLBT<String> pu = new MyLBT<>();
		MyLBT<String> la = new MyLBT<>();
		
		ja.makeTree(15,a,a);
		je.makeTree(23,ja,a);
		ja.makeTree(12,a,a);
		ji.makeTree(45,a,a);
		jo.makeTree(10,ji,ja);
		ja.makeTree(34,jo,je);
		je.makeTree(1,a,a);
		jo.makeTree(87,a,a);
		ju.makeTree(52,ja,jo);
		ja.makeTree(9,a,a);
		je.makeTree(20,a,a);
		ji.makeTree(60,je,ja);
		ja.makeTree(5,a,a);
		je.makeTree(100,a,a);
		jo.makeTree(98,je,ja);
		ja.makeTree(21,jo,ji);
		je.makeTree(75,a,a);
		ji.makeTree(4,a,a);
		jo.makeTree(68,ji,je);
		je.makeTree(110,a,a);
		ji.makeTree(14,a,a);
		ya.makeTree(2,ji,je);
		ji.makeTree(16,ya,jo);
		je.makeTree(36,ji,ja);
		ja.makeTree(50,je,ju);
		
		pa.makeTree("...",x,x);
		pe.makeTree("_",pa,x);
		pa.makeTree("_",x,x);
		pi.makeTree("sumerce",x,x);
		po.makeTree("este",pi,pa);
		pa.makeTree("como",po,pe);
		pe.makeTree("_",x,x);
		po.makeTree(",",x,x);
		pu.makeTree("_",pa,po);
		pa.makeTree("_",x,x);
		pe.makeTree("a",x,x);
		pi.makeTree("_",pe,pa);
		pa.makeTree("_",x,x);
		pe.makeTree("dirigido",x,x);
		po.makeTree("ver",pe,pa);
		pa.makeTree("_",po,pi);
		pe.makeTree("_",x,x);
		pi.makeTree("va",x,x);
		po.makeTree("_",pi,pe);
		pe.makeTree("_",x,x);
		pi.makeTree("mensaje",x,x);
		la.makeTree("puede",pi,pe);
		pi.makeTree("Yoan",la,po);
		pe.makeTree("Profe",pi,pa);
		pa.makeTree("Hola",pe,pu);
		
		//Integer
		//Orders
		System.out.println( "+++++++INTEGER TREE++++++++" );
		System.out.println( "Level-Order:" );
		ja.levelOrderOutput();
		System.out.println();
		System.out.println( "Pre-Order:" );
		ja.preOrderOutput();
		System.out.println();
		System.out.println( "In-Order:" );
		ja.inOrderOutput();
		System.out.println();
		System.out.println( "Post-Order:" );
		ja.postOrderOutput();
		System.out.println();
		System.out.print("\n");
		//Brother
		System.out.println(ja.brother(87));
		//Shuffle
		System.out.println( "The same but shuffled (Level-Order): " );
		ja.shuffle();
		ja.levelOrderOutput();
		System.out.println();
		System.out.print("\n");
		//Diameter
		System.out.println("Diameter: "+ja.diameter());
		
		//String
		//Orders
		System.out.println( "\n\n+++++++STRING TREE++++++++" );
		System.out.println( "Level-Order:" );
		pa.levelOrderOutput();
		System.out.println();
		System.out.println( "Pre-Order:" );
		pa.preOrderOutput();
		System.out.println();
		System.out.println( "In-Order:" );
		pa.inOrderOutput();
		System.out.println();
		System.out.println( "Post-Order:" );
		pa.postOrderOutput();
		System.out.println();
		System.out.print("\n");
		//Brother
		System.out.println(pa.brother("Yoan"));
		//Shuffle
		System.out.println( "The same but shuffled (Level-Order): " );
		pa.shuffle();
		pa.levelOrderOutput();
		System.out.println();
		System.out.print("\n");
		//Diameter
		System.out.println("Diameter: "+pa.diameter());
	}
	
	public T brother(T el){
		BinaryTreeNode<T> t;
		LinkedQueue<BinaryTreeNode<T>> q = new LinkedQueue<>();
		q.put(root);
		System.out.print("The brother of " + el + " is: ");
		while(!q.isEmpty()){
			t = q.remove();
			if(t == null) continue;
			try{
			if( t.leftChild.element.equals(el) && t.rightChild.element != null )
				return t.rightChild.element;
			else if( t.rightChild.element.equals(el) && t.leftChild.element != null )
				return t.leftChild.element;
			}
			catch(NullPointerException e){
				System.out.print(e);		
			}
			q.put( t.leftChild);
			q.put( t.rightChild );
		}
		return null;
	}
	
	public void shuffle(){
        ArrayStack<BinaryTreeNode<T>> este = new ArrayStack<>();
		ArrayStack<BinaryTreeNode<T>> otro = new ArrayStack<>();
        BinaryTreeNode<T> aux = root;
        T miT;
        este.push(aux);
        otro.push(null);
        while(!este.isEmpty()&&aux!=null){
            aux = este.peek();
            if(este.peek() == otro.peek()){
                if(aux.leftChild != null && aux.rightChild != null){
                    miT = aux.leftChild.element;
                    aux.leftChild.element=aux.rightChild.element;
                    aux.rightChild.element=miT;
                }
                este.pop();
                otro.pop();
            }
            else{
                if(aux.leftChild != null || aux.rightChild != null){
                    if(aux.rightChild != null)
						este.push(aux.rightChild);
                    if(aux.leftChild!=null)
						este.push(aux.leftChild);
                    otro.push(aux);
                }
                else
                    este.pop();
            }
        }
    }
	
	@Override
    public void preOrderOutput(){
        ArrayStack<BinaryTreeNode<T>> pre = new ArrayStack<>();
        BinaryTreeNode<T> aux = root;
        pre.push(aux);
        while(!pre.isEmpty() && aux != null){
            aux = pre.pop();
            System.out.print(aux.element+" ");
            if(aux.rightChild != null)
                pre.push(aux.rightChild);
            if(aux.leftChild!=null)
                pre.push(aux.leftChild);
        }
    }
	
	 @Override
    public void inOrderOutput(){
        ArrayStack<BinaryTreeNode<T>> in = new ArrayStack<>();
		ArrayStack<BinaryTreeNode<T>> visit = new ArrayStack<>();
        BinaryTreeNode<T> aux = root;
        in.push(aux);
        visit.push(null);
        while(!in.isEmpty() && aux!=null){
            aux = in.peek();
            if(in.peek() == visit.peek()){
                System.out.print(in.pop()+" ");
                visit.pop();
                if(aux.rightChild != null)
                    in.push(aux.rightChild);
            }
            else{
                if(aux.leftChild != null){
                    in.push(aux.leftChild);
                    visit.push(aux);
                }
                else if(aux.rightChild != null){
                    System.out.print(in.pop()+" ");
                    in.push(aux.rightChild);
                }
                else System.out.print(in.pop()+" ");
            }
        }
    }
	
	    @Override
    public void postOrderOutput(){
        ArrayStack<BinaryTreeNode<T>> post = new ArrayStack<>();
		ArrayStack<BinaryTreeNode<T>> visit = new ArrayStack<>();
        BinaryTreeNode<T> aux=root;
        post.push(aux);
        visit.push(null);
        while(!post.isEmpty() && aux!=null){
            aux = post.peek();
            if(post.peek() == visit.peek()){
                System.out.print(post.pop()+" ");
                visit.pop();
            }
            else{
                if(aux.leftChild != null || aux.rightChild != null){
                    if(aux.rightChild != null)
						post.push(aux.rightChild);
                    if(aux.leftChild != null)
						post.push(aux.leftChild);
                    visit.push(aux);
                }
                else System.out.print(post.pop()+" ");
            }
        }
    }
	
	public int diameter(){
		return theDiameter(root);
	}
	
	public static<T> int theDiameter(BinaryTreeNode<T> t) {        
		if (t == null) return 0;
		int rootDiameter = getHeight(t.leftChild) + getHeight(t.rightChild) + 1;
		int leftDiameter = theDiameter(t.leftChild);
		int rightDiameter = theDiameter(t.rightChild);
		return Math.max(rootDiameter, Math.max(leftDiameter, rightDiameter));
	}

	public static int getHeight(BinaryTreeNode t) {
    if (t == null) return 0;
    return Math.max(getHeight(t.leftChild), getHeight(t.rightChild)) + 1;
	}
}


package unal.datastructures;

import java.util.*;
import java.lang.Math;

public class LinearListPriorityQueue<T extends Comparable<? super T>> implements MaxPriorityQueue<T>{
	
	T[] element;
	int size;

	@SuppressWarnings("unchecked")
	public LinearListPriorityQueue ( int initialCapacity ) 
	{
		if( initialCapacity < 1 )
			throw new IllegalArgumentException
				( "initialCapacity must be >= 1" );
		element = ( T[] ) new Comparable[ initialCapacity ];
		size = 0;
	}
	public LinearListPriorityQueue ( )
	{
		this( 10 ); 
	}
	public boolean isEmpty ( ) 
	{
		return size == 0; 
	}
	public int size ( ) 
	{ 
		return size;
	}
	void checkIndex( int index )
	{
		if( index < 0 || index >= size )
			throw new IndexOutOfBoundsException
				( "index = " + index + " size = " + size);
	}
	public T getMax ( ) 
	{ 
		if (!(this.isEmpty())){
			T max = element[ 0 ];
			for( int i = 0; i < size; i++ ){
				if( max.compareTo( element[ i ] ) < 0)
					max = element[ i ];  
			}
			return max;
		}
		return null; 
	}
	public void put ( T theElement ) 
	{ 
		element[ size ] = theElement;
		size++;
	}
	public T remove ( int index )
	{
		checkIndex( index );
		T removedElement = element[ index ];
		for( int i = index + 1; i < size; i++)
			element[ i - 1 ] = element[ i ];
		element[ --size ] = null;
		return removedElement;
	}
	public T removeMax ( ) 
	{
		if (!(this.isEmpty())){
			int index = 0;
			T max = element[ 0 ];
			for( int i = 0; i < size; i++ ){
				if( max.compareTo( element[ i ] ) < 0){
					index = i;
					max = element[ i ];  
				}
			}
			return remove( index );
		}
		return null;  

	}
	public String toString ( ) 
	{ 
		StringBuilder s = new StringBuilder( );
		s.append( "The " + size + " element are [ " );
		if( size > 0 ){
			s.append( Objects.toString( element[ 1 ] ) );
			for( int i = 2; i <= size; i++ )
				s.append( ", " + Objects.toString( element[ i ] ) );
		}
		s.append( " ]" );
		return new String( s );
		}
	
	public static void main ( String[] args ) 
	{ 
		long time;

		LinearListPriorityQueue<Integer> l = new LinearListPriorityQueue<>( 100000 );

		MaxHeap<Integer> h = new MaxHeap<>( 100000 );

		
		time = System.currentTimeMillis( );
		for( int i = 0; i < 100000; i++ ){
			l.put( new Integer ((int) (Math.random()*1000000+1))); 
		}
		time = System.currentTimeMillis( ) - time;
		System.out.println( "El tiempo en microsegundos para la fase I con LinearListPriorityQueue fue: " + time );

		time = System.currentTimeMillis( );
		for( int i = 0; i < 100000; i++ ){
			h.put( new Integer ((int) (Math.random()*1000000+1))); 
		}
		time = System.currentTimeMillis( ) - time;
		System.out.println( "El tiempo en microsegundos para la fase I con MaxHeap fue: " + time );

		time = System.currentTimeMillis( );
		for( int i = 0; i < 50000; i++ ){
			l.removeMax(); 
			l.getMax(); 
		}
		time = System.currentTimeMillis( ) - time;
		System.out.println( "El tiempo en microsegundos para la fase II con LinearListPriorityQueue fue: " + time );

		time = System.currentTimeMillis( );
		for( int i = 0; i < 50000; i++ ){
			h.removeMax(); 
			h.getMax();  
		}
		time = System.currentTimeMillis( ) - time;
		System.out.println( "El tiempo en microsegundos para la fase II con MaxHeap fue: " + time );
	}
}


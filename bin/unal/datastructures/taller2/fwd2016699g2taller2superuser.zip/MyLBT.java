import java.lang.reflect.Method;

public class MyLBT<T> extends LinkedBinaryTree<T>{

	public MyLBT(){
		super();
		}

	public T brother(T hermano){
		 ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
	     BinaryTreeNode<T> t = root;
	     if (t.element.equals(hermano))
	    	 return null;

	     while( t != null ){
	    	 
	    	 if (t.leftChild!=null){

	    	 if(t.leftChild.element.equals(hermano)){
	    		if (t.rightChild == null) return null;
	    		return t.rightChild.element;}
	    	 }
	    	 
	    	if (t.rightChild !=null){
	    	if(t.rightChild.element.equals(hermano) ){
	    		if ( t.leftChild == null) return null;
	    		return t.leftChild.element;}
	    	}

	    	if( t.leftChild != null )
	            q.put( t.leftChild );
	         if( t.rightChild != null )
	            q.put( t.rightChild );
	         t=q.remove();
	        //System.out.println(t.element);
	    	}
	      return null;
	}
	
	public void shuffle ( ){
				
		ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>( );
		ArrayQueue<Integer> pos = new ArrayQueue<>();
		
		ArrayLinearList<T> s = new ArrayLinearList<>();
		ArrayLinearList<T> sf = new ArrayLinearList<>();
				
		BinaryTreeNode<T> t = root;
		
		s.add(0,root.element);
		pos.put(3);
				
		while (t != null){
			
			 if( t.leftChild != null ){
				 s.add( 0,t.leftChild.element );
				 pos.put(1);
				 q.put( t.leftChild );
			 }
			 if( t.rightChild != null ){
		         s.add( 0,t.rightChild.element );
		         pos.put(2);
		         q.put( t.rightChild );
			 }
			
			t = (BinaryTreeNode <T>) q.remove();
			}
		
		// Ramdom elementos del arbol
		
		while (s.isEmpty()==false){
			int x = new Double(Math.random() * s.size()).intValue();
			sf.add(0,s.remove(x));

		}
		
		// poner los elementos ya reordenados en el Arbol
		
		t = root;
		t.element= sf.get(0);
				
		int posAux = 1;
		
		while (t !=null){
			
			 if( t.leftChild != null ){
				 t.leftChild.element = sf.get(posAux);
				 q.put( t.leftChild );
				 posAux=posAux+1;
			 }
			 if( t.rightChild != null ){
				 t.rightChild.element = sf.get(posAux);
				 q.put( t.rightChild );
				 posAux=posAux+1;
			 }
			
			 t = (BinaryTreeNode <T>) q.remove();
		}	
	}

	      

	 public static void main( String[] args ){

		 MyLBT<Integer> a = new MyLBT<>( ),
		         x = new MyLBT<>( ),
		         y = new MyLBT<>( ),
		         z = new MyLBT<>( ),
		 		 v =new MyLBT<>(),
		 		 w= new MyLBT<>( );

		 	w.makeTree (new Integer (7),a,a);
		    v.makeTree (new Integer (3),w,a);
		    z.makeTree (new Integer (8),a,a);

		    y.makeTree (new Integer (4),z,a);

		    x.makeTree (new Integer (1),v,y);
		    w.makeTree (new Integer (9),a,a);
		    v.makeTree (new Integer (10),a,a);

		    z.makeTree (new Integer (5),w,v);

		    w.makeTree (new Integer (11),a,a);
		    v.makeTree (new Integer (6),a,w);
		    y.makeTree (new Integer (2),z,v);

		    z.makeTree (new Integer (0),x,y);
		    
		    int h = 3;
		    System.out.println("El Hermano de " + h + " es : ");
		    System.out.println(z.brother(h));
		    
		    System.out.println("Arbol Original : ");
		    z.levelOrderOutput();

		    		    
		    z.shuffle();
		    System.out.println();
		    System.out.println("Shuffle Tree : ");
		    z.levelOrderOutput();
		    
		    
		   
		    

	 }

	

}

package datastructures;

import java.util.Iterator;

public class KSumPair {

   public static int solve(LinearList<Integer> A,LinearList<Integer> B,int k){
	   MaxHeap<Integer> q=new MaxHeap<>();
	   int t=k;
	   if(k>A.size()-1)
		   t=A.size()-1;
	   for (int i=0;i<=t;i++){
		   for(int j=0;j<=t;j++){
			   q.put(A.get(i)+B.get(j));
		   }
	   }
	   if(k<=(A.size()*B.size())-1){
		   for(int i=0;i<k;i++)
			   System.out.println("the element "+q.removeMax());
		   return q.removeMax();
	   }
	   else   
		 throw new IllegalArgumentException("no existe la posicion"+ k +"en el arreglo");
  }
   public static void main(String [] args){
	// test default constructor
    LinearList<Integer> x = new ArrayLinearList<>( );
    LinearList<Integer> z = new ArrayLinearList<>( );

    // test size
    System.out.println( "Initial size X is " + x.size( ) );
    System.out.println( "Initial size Z is " + z.size( ) );

    // test put
    x.add( 0, new Integer( 13 ) );
    x.add( 1, new Integer( 4 ) );
    x.add( 2, new Integer( 3 ) );
    x.add( 3, new Integer( 1 ) );
   
    System.out.println( "List size is " + x.size( ) );
    
    z.add( 0, new Integer( 15 ) );
    z.add( 1, new Integer( 8 ) );
    z.add( 2, new Integer( 1 ) );
    z.add( 3, new Integer( 0 ) );
   
    System.out.println( "List size is " + z.size( ) );
    System.out.println( "List  is " + x);
    System.out.println( "List  is " + z);
   
    System.out.println("The elemento k is: "+solve(x,z,new Integer(14)));
   }
}

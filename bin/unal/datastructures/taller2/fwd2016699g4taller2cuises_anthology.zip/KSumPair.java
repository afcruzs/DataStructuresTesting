package unal.datastructures.taller2;
import java.util.*;


	@SuppressWarnings("Unchecked")
	public class KSumPair<T extends Comparable<? super T>>
				implements MaxPriorityQueue<T>{

		T[] heap;   // array for complete binary tree
   		int size;   // number of elements in heap
		static int counter=0; //cycles till k
		



   	// constructors
   	@SuppressWarnings( "unchecked" )
   	public KSumPair( int initialCapacity )
   	{
      		if( initialCapacity < 1 )
       		  throw new IllegalArgumentException
            		( "initialCapacity must be >= 1" );
      		heap = ( T[] ) new Integer[ initialCapacity + 1 ];
      		size = 0;
   }

   /** create a heap with initial capacity 10 */
   public KSumPair( )
   {
      this( 10 );
   }

   // methods
   /** @return true iff the heap is empty */
   public boolean isEmpty( )
   {
      return size == 0;
   }

   /** @return number of elements in the heap */
   public int size( )
   {
      return size;
   }

   /** @return maximum element
    * @return null if the heap is empty */
   public T getMax( )
   {
      return ( size == 0 ) ? null : heap[ 1 ];
   }

   /** put theElement into the heap */
   @SuppressWarnings( "unchecked" )
   public void put( T theElement )
   {
      // increase array size if necessary
      if( size == heap.length - 1 )
      {
         T[] old = heap;
         heap = ( T[] ) new Integer[ 2 * heap.length ];
         for( int i = 0; i < old.length; i++ )
            heap[ i ] = old[ i ];
      }

      // find place for theElement
      // currentNode starts at new leaf and moves up tree
      int currentNode = ++size;
      while( currentNode != 1 &&
             heap[ currentNode / 2 ].compareTo( theElement ) < 0 )
      {
         // cannot put theElement in heap[ currentNode ]
         heap[ currentNode ] = heap[ currentNode / 2 ]; // move element down
         currentNode /= 2; // move to parent
      }

      heap[ currentNode ] = theElement;
   }

    /** initialize max heap to element array theHeap */
   @SuppressWarnings("unchecked")
   public void initialize( T[] theHeap )
   {
      int theSize = theHeap.length;
      heap = ( T[] ) new Integer[ theSize + 1 ];
      for( int i = 1; i< heap.length; i++ )
         heap[ i ] = theHeap[ i - 1 ];
      size = theSize;
      // heapify
      for( int root = size / 2; root >= 1; root-- )
      {
         T rootElement = heap[ root ];

         // find place to put rootElement
         int child = 2 * root; // parent of child is target
         // location for rootElement
         while( child <= size )
         {
            // heap[ child ] should be larger sibling
            if( child < size &&
                heap[ child ].compareTo( heap[ child + 1 ] ) < 0 ) child++;

            // can we put rootElement in heap[ child / 2 ]?
            if( rootElement.compareTo( heap[ child ] ) >= 0 )
               break;  // yes

            // no
            heap[ child / 2 ] = heap[ child ]; // move child up
            child *= 2; // move down a level
         }
         heap[ child / 2 ] = rootElement;
      }
   }

    public T removeMax( )
   {
      // if heap is empty return null
      if( size == 0 ) return null;       // heap empty

      T maxElement = heap[ 1 ];  // max element

      // reheapify
      T lastElement = heap[ size-- ];

      // find place for lastElement starting at root
      int currentNode = 1,
         child = 2;     // child of currentNode
      while( child <= size )
      {
         // heap[ child ] should be larger child of currentNode
         if( child < size &&
             heap[ child ].compareTo( heap[ child + 1 ] ) < 0 ) child++;

         // can we put lastElement in heap[ currentNode ]?
         if( lastElement.compareTo( heap[ child ] ) >= 0 )
            break;   // yes

         // no
         heap[ currentNode ] = heap[ child ]; // move child up
         currentNode = child; // move down a level
         child *= 2;
      }
      heap[ currentNode ] = lastElement;

      return maxElement;
   }

   @Override
   public String toString( )
   {
      StringBuilder s = new StringBuilder( );
      s.append( "The " + size + " elements are [ " );
      if( size > 0 )
      {  // nonempty heap
         // do first element
         s.append( Objects.toString( heap[ 1 ] ) );
         // do remaining elements
         for( int i = 2; i <= size; i++ )
            s.append( ", " + Objects.toString( heap[ i ] ) );
      }
      s.append( " ]" );

      return new String( s );
   }

	public static int solve(ArrayLinearList<Integer> a,ArrayLinearList<Integer> b,int k){

		int posibles = a.size * b.size;
		//Verify, if k-sum exists
		if(k>posibles){
			return -1;
		}

		KSumPair<Integer> h = new KSumPair<Integer>(k+1);//heap capacity must be k+1
		KSumPair<Integer> r = new KSumPair<Integer>(k+1);//heap capacity must be k+1

		//Add first k-elements founded
		 
      		for(int i=0;i<a.size;i++){
	         for(int j=0;j<b.size;j++){
			Integer e = (a.get(i)+b.get(j));   
			if(h.counter<=k){
				h.put(e);
				h.counter++;
			}
	 	 }                        
        	}
	
	System.out.println(h);

      //heapify-organize first k-elements in new heap (r)
	for(int x=0;x<=k;x++){
		r.put(h.removeMax());
	}

	
	//Special Case, r.heap[0] must be null
	if(k==0)
	return r.heap[1];
	else{

      //Verify remaining sums, put only if e>r.heap[(r.size)], otherwise ignore sum/actual.
      for(int i=0;i<a.size;i++){
         for(int j=0;j<b.size;j++){
         	Integer e = a.get(i)+b.get(j);
         	if(e>r.heap[(r.size)]&&e<r.heap[(r.size)-1]&&k!=0){
            		r.heap[(r.size)]=e;                                 
         	}
   

         }
      }

	System.out.println(r);
	}

      return r.heap[k+1];
}

	public static void main(String args[]){

		ArrayLinearList<Integer> a = new ArrayLinearList<>();

			a.add(0,13);
			a.add(1,4);
			a.add(2,2);

		ArrayLinearList<Integer> b = new ArrayLinearList<>();

			b.add(0,15);
			b.add(1,8);
			b.add(2,1);

		System.out.println(solve(a,b,0));
		
		
		
	}


}
 


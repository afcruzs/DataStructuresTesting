package unal.datastructures.taller2;
import java.util.*;
import unal.datastructures.*;

public class LinearListPriorityQueue <T extends Comparable <? super T>> implements MaxPriorityQueue<T>
{
	Chain<T> tChain ;
	int size ;
	
	public LinearListPriorityQueue ()
	{
      tChain =  new Chain<T>();
      size = 0;
	}
		
   public boolean isEmpty( )
   {
	 return size == 0;
   }
   
   
   public int size( )
   {
	return size-1;
   }
   
   
   public T getMax( )
   {
	return ( size == 0 ) ? null : tChain.get(1);
   }
   
   public void put( T theElement )
   {	   
	 if( size == 0)
	 {
		tChain.add(0,null);
		size++;
		tChain.add(size++,theElement);
	 }
		else
		{
			tChain.add(size,theElement);
			size++;
			int cN = size-1;
			while( cN != 1 &&
				tChain.get(cN/2).compareTo( theElement ) < 0 )
			{
				// cannot put theElement in heap[ cN ]
				tChain.remove(cN);
				tChain.add(cN,tChain.get((cN/2)));
				cN /= 2; // move to parent
			}
			if(cN != size)
			{
				tChain.remove(cN);
				tChain.add(cN,theElement);			
			}
		
		}
     
   }
   
  
   public T removeMax( )
   {
	  if( size == 0 ) return null;       // heap empty
		
      T maxElement = tChain.get(1);  // max element
	
      // reheapify
      T lastElement = tChain.get(size-1);
	  
	  
      // find place for lastElement starting at root
      int cN = 1,
         child = 2;     // child of cN
      while( child <= size )
      {
		
         // heap[ child ] should be larger child of cN
         if( child < size &&
             tChain.get( child).compareTo( tChain.get( child+1 ) ) < 0 ) child++;
			 
         // can we put lastElement in heap[ cN ]?
         if( lastElement.compareTo( tChain.get(child )) >= 0 )
            break;   // yes
         // no
		tChain.remove(cN);
		size--;
		tChain.add(cN,tChain.get(child-1));
		
		cN = child;
        child *= 2;
      }
		tChain.remove(cN);
		tChain.add(cN,lastElement);
		
      return maxElement;
   }
   
      @Override
   public String toString( )
   {
      StringBuilder s = new StringBuilder( );
      s.append( "The " + this.size() + " elements are [ " );
	  s.append( Objects.toString( tChain.get(1)) ) ;
      if( size > 0 )
      {
         for( int i = 2; i < size; i++ )
            s.append( ", " + Objects.toString( tChain.get(i)) );
      }
      s.append( " ]" );
      return new String( s );
   }
  

   public static void main (String [] args)
   {
   
   
   int x=1;	//variable para generar numero aleatoriamente

		int aux=1;
		int element[] = new int [100000];
		int operaciones[] = new int[15000];

		for (int i = 0; i<100000; i++){
			aux =  (int) Math.round((Math.random()*100000));
			element [i] = aux;
			//System.out.println(i);
		}
		
		// FASE 1.
		//adicion de 10000 element en Maxheap  
		MaxHeap<Integer> h = new MaxHeap<>( );
		long time = System.currentTimeMillis( );

		for (int i = 0; i<100000; i++){
			h.put( element[i]  );
			
		}

		time=System.currentTimeMillis()-time;
		System.out.println("el tiempo en  primera fase"+time);
		//System.out.println("maxheap...."+time);
		
		
		// FASE 2
		//realizar  50.000 operaciones intercaladas {remove max(),get max()}
		
		long time2 = System.currentTimeMillis( );
		for (int i = 1 ; i<=50000; i++){
			x =  (int) Math.round((Math.random()*100000));
			if(i%2 == 1 ){
				//para numeros de i impares se hace una insercion 

				h.put( x );
			}
			else{
				h.removeMax ( );
			} 
		}
		time2=System.currentTimeMillis()-time2;
		System.out.println("segunda fase"+time2);
		}
   
   
		/* LinearListPriorityQueue <Integer> h =  new LinearListPriorityQueue <>();
		MaxHeap<Integer> a= new MaxHeap<>();
		int  aleatorio;
		long time2;
		long time3;
		long time4;
		
		
		long time = System.currentTimeMillis( );
		for(int i=1; i<=100000;i++)
		{
				aleatorio=(int) Math.round((Math.random()*20));
				//System.out.println(i);
				h.put(aleatorio);
		}
		
		 time=System.currentTimeMillis()-time;
		 
		 
		time2 = System.currentTimeMillis( );
		for(int j=1; j<=50000;j++)
		 {
			if(j%2==0)
			{
			//System.out.println(h.removeMax());
			h.removeMax();
			}
			else
			{
			
			//System.out.println(h.getMax());
			h.getMax();
			}
		 }
		 
		 time2=System.currentTimeMillis()-time2;
		 
	
		 
		  System.out.println("Primera fase LinearListPriorityQueue: "+time);
		 System.out.println("segunda fase LinearListPriorityQueue: "+time2);
		 
		 
		 
		 
   }
  */
}

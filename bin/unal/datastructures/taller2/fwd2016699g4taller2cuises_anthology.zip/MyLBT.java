package unal.datastructures.taller2;
import java.util.*;
import java.lang.reflect.Method;

class MyLBT<T extends Comparable <T>> extends LinkedBinaryTree<T>
{
	
	// brother 
	 public T brother( T elemento )
	{
		BinaryTreeNode<T> t;
		LinkedQueue < BinaryTreeNode <T> > a = new LinkedQueue<>();
		a.put( root );
		
		while( !a.isEmpty() )
		{
			t = a.remove();
			if( t == null ) continue;
			try{
			if( t.leftChild.element.equals(elemento) && t.rightChild.element != null )
				return t.rightChild.element;
			else if( t.rightChild.element.equals(elemento) && t.leftChild.element != null )
				return t.leftChild.element;
			}catch(NullPointerException e)
			{
			 System.out.println(e);
			}
			
		    a.put( t.leftChild);
			a.put( t.rightChild );
		}
		return null;
	}

	//  shuffle
	
		public void shuffle()
		{
			BinaryTreeNode<T> t;
			LinkedQueue < BinaryTreeNode <T> > q = new LinkedQueue<>();
			ArrayList<T> agrega= new ArrayList<>();
			int aleatorio=0;
			q.put( root );
  
			while( !q.isEmpty() )
			{

			   t = q.remove();
			   if( t == null ) continue;
			   agrega.add(0,t.element);
			   if(t.leftChild == null && t.rightChild == null ) continue;
			 
			   q.put( t.leftChild);
			   q.put( t.rightChild );
			}
  
			q.put(root);

		  while( !q.isEmpty()  && !agrega.isEmpty())
		  {
				t = q.remove();
				if( t == null ) continue;
				if(agrega.size() !=0)
				{
			    aleatorio=(int)(Math.random()*agrega.size());
			    t.element=agrega.remove(aleatorio); 
				}
			else
		        {
		         t.element=agrega.remove(aleatorio);
		        }
   
			   if(t.leftChild == null && t.rightChild == null ) continue;
			   
			   q.put( t.leftChild);
			   q.put( t.rightChild );
		}

	}
	
	@SuppressWarnings("unchecked")
		public void inOrder()
			 {
			  BinaryTreeNode<T> m = this.root;
			  ArrayStack<BinaryTreeNode> stack = new ArrayStack<>();

			  stack.push(m);
			  //System.out.println(r.element);
			  while(!stack.isEmpty())
			  {
			   //r = stack.pop();
			   if(m.leftChild != null && m.equals(stack.peek()))
			   {
				//stack.push(r);
				stack.push(m.leftChild);
				m = m.leftChild;
			   }
			   else 
			   {
				 
				m = stack.pop();
				System.out.print(m.element+ " ");
				if(m.rightChild != null)
				{
				 stack.push(m.rightChild);
				 m = m.rightChild;
				}
				
			   }
			  }
			 }


		//@Override
		public void preOrder(){

			LinkedStack<BinaryTreeNode<T>> a = new LinkedStack<>();
			BinaryTreeNode<T> t= root;
			
			a.push( t );
			for(int i=0; i<size();i++){
			System.out.print(t.element + " ");
			if (t.rightChild != null)
			a.push( t.rightChild );
			if (t.leftChild != null)
			a.push( t.leftChild );
			t = ( BinaryTreeNode<T> ) a.pop( );

			}
		}

        //@Override
		public void postOrder()
		{
			LinkedStack<T> cute = new LinkedStack<>();
			LinkedStack<BinaryTreeNode<T>> q = new LinkedStack<>( );
			BinaryTreeNode<T> t = root;
			//System.out.print("postOrder:");
			int count = 0;

			while(count < size())
			{
				cute.push( t.element);
				if(t.leftChild != null)
				q.push( t.leftChild );
				if(t.rightChild != null)
				q.push( t.rightChild );

				if(!q.isEmpty())
					t = q.pop( );
				count++;
			}
			while(!cute.isEmpty())
			System.out.print(" " +cute.pop());
		}
		
		
		public int theDiameter (BinaryTreeNode<T> t)
		{
		  if (t == null) return 0;
		  else return Math.max ( theDiameter (t.leftChild), Math.max (theDiameter (t.rightChild),
			heigh (t.leftChild) + heigh (t.rightChild) + 1));
		 }

		public int heigh (BinaryTreeNode<T> t)
		{
		  if (t == null) return 0;
		  else return 1 + Math.max (heigh (t.leftChild), heigh (t.rightChild));
		}
		public int diameter ()
		 {
		  return theDiameter(root);
		 }



public static void main(String[] args)

	{

		MyLBT<Character>a= new MyLBT<>();
		MyLBT<Character>x= new MyLBT<>();
		MyLBT<Character>y= new MyLBT<>();
		MyLBT<Character>z= new MyLBT<>();
		MyLBT<Character>w= new MyLBT<>();
		MyLBT<Character>m= new MyLBT<>();
		MyLBT<Character>s= new MyLBT<>();
		MyLBT<Character>p= new MyLBT<>();
		
		x.makeTree('P',a,a);
		y.makeTree('Q',a,a);
		z.makeTree('H',x,y); 
		x.makeTree('R',a,a);
		y.makeTree('S',a,a);
		w.makeTree('I',x,y);
		x.makeTree('T',a,a);
		y.makeTree('J',x,a);
		m.makeTree('K',a,a);
		s.makeTree('D',z,w);
		z.makeTree('E',y,m);
		x.makeTree('L',a,a);
		y.makeTree('M',a,a);
		m.makeTree('F',x,y);
		x.makeTree('N',a,a);
		y.makeTree('O',a,a);
		p.makeTree('G',x,y);
		x.makeTree('B',s,z);
		y.makeTree('C',m,p);
		z.makeTree('A',x,y); 
		
		
	
		System.out.println("\nPrueba para arbol 1\n");
		 z.levelOrderOutput( );
		System.out.println();
		
		//test brother
		System.out.println("\nEl hermano del elemento R es "+z.brother('R'));
		
		//test  InOrder
		System.out.println("\n InOrder1\n");
		z.inOrder();
		System.out.println("\n" );
		z.inOrderOutput();
		System.out.println();
		
		//test preOrder
		System.out.println("\n preOrder1\n");
		z.preOrder();
		System.out.println("\n" );
		z.preOrderOutput();
		System.out.println();
		
		//test PostOrder
		System.out.println("\n postOrder1\n");
		z.postOrder();
		System.out.println("\n" );
		z.postOrderOutput();
		
		//test diametro
		System.out.println("\n El diametro del arbol es1");
		System.out.println( z.diameter() ); 
		
		
		//test shuffle
		z.shuffle();
		System.out.println("\nCambia los nodos de manera aleatoria1\n");
		z.levelOrderOutput( );
		
		MyLBT<Integer>c= new MyLBT<>();
		MyLBT<Integer>i= new MyLBT<>();
		MyLBT<Integer>j= new MyLBT<>();
		MyLBT<Integer>k= new MyLBT<>();
		MyLBT<Integer>r= new MyLBT<>();
		MyLBT<Integer>n= new MyLBT<>();
		MyLBT<Integer>t= new MyLBT<>();
		MyLBT<Integer>u= new MyLBT<>();
		
		i.makeTree(16,c,c);
		j.makeTree(17,c,c);
		k.makeTree(8,i,j); 
		i.makeTree(18,c,c);
		j.makeTree(19,c,c);
		r.makeTree(9,i,j);
		i.makeTree(20,c,c);
		j.makeTree(10,i,c);
		n.makeTree(11,c,c);
		t.makeTree(4,k,r);
		k.makeTree(5,j,n);
		i.makeTree(12,c,c);
		j.makeTree(13,c,c);
		n.makeTree(6,i,j);
		i.makeTree(14,c,c);
		j.makeTree(15,c,c);
		u.makeTree(7,i,j);
		i.makeTree(2,t,k);
		j.makeTree(3,n,u);
		k.makeTree(1,i,j); 
		
	   System.out.println("\nPrueba para arbol 2\n");
		System.out.println("\n test inOrder de enteros");
		//test in order 
		k.inOrder();
		System.out.println("\n");
		k.inOrderOutput();

		//test preOrder
		System.out.println("\n preOrder2\n");
		k.preOrder();
		System.out.println("\n");
		k.preOrderOutput();
		
		//test PostOrder
		System.out.println("\n postOrder2\n");
		k.postOrder();
		System.out.println("\n");
		k.postOrderOutput();
		
		//test diametro
		System.out.println("\n El diametro del arbol es");
		System.out.println( k.diameter() ); 
		
		//test brother
		System.out.println("\nEl hermano del elemento 10 es "+k.brother(10));
		
		//test  suffle 
		System.out.println("\nCambia los nodos de manera aleatoria2\n");
		k.shuffle();
		k.levelOrderOutput( );
		//System.out.println("\nCambia los nodos de manera aleatoria\n");
		//z.levelOrderOutput( );
		
		
	}









}



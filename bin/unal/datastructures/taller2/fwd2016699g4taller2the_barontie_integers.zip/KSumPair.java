package unal.datastructures.taller2;
import java.util.*;

public class KSumPair<T extends Comparable<? super T>>{
	public static void main (String[] args){
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		LinearList<Integer> listA = new ArrayLinearList<>();
		LinearList<Integer> listB = new ArrayLinearList<>();
		
		listA.add(0,13);
		listA.add(0,4);
		listA.add(0,2);
		listB.add(0,15);
		listB.add(0,8);
		listB.add(0,1);
		System.out.println("List A is: " + listA);
		System.out.println("List B is: " + listB);
		sort(listA);
		sort(listB);
		System.out.println("List A sorted is: " + listA);
		System.out.println("List B sorted is: " + listB);
		slove(listA,listB,1);
		LinearList<Integer> total = new ArrayLinearList<>();
		for (int i = 0;  i < listA.size(); i++) {
			for (int j = 0; j < listA.size(); j++) {
				int aux = listA.get(i)+listB.get(j);
				total.add(0,aux);
			}
		}
		sort(total);
		System.out.println("List total sorted is: " + total);
		System.out.println(slove(listA,listB,n));
	}
	public static int slove(LinearList<Integer> a, LinearList<Integer> b, int k){
		int size = a.size(); 
		Integer[] a1 = (Integer[]) new Integer[size];
		Integer[] a2 = (Integer[]) new Integer[size];
		for(int i = 0; i < size; i++){
			a1[i] = a.get(i); a2[i] = b.get(i);
		}
		MaxHeap<Integer> m1 = new MaxHeap<>();
		MaxHeap<Integer> m2 = new MaxHeap<>();
		m1.initialize(a1);
		m2.initialize(a2);
		System.out.println(m1);
		System.out.println(m2);
		MaxHeap<Integer> mm1 = new MaxHeap<>();
		MaxHeap<Integer> mm2 = new MaxHeap<>();
		int max1 = 0;//m1.removeMax();
		int max2 = 0;//m2.removeMax();
		int theSlove = max1 + max2;
		for(int i = 0; i <=k; i++){
				System.out.println(theSlove);
			if (m1.isEmpty()) {
				m1 = mm1;
				mm1 = new MaxHeap<>();
				//max1 = m1.removeMax();
			}
			if (m2.isEmpty()) {
				m2 = mm2;
				mm2 = new MaxHeap<>();
				//max2 = m2.removeMax();
			}
			max1 = m1.removeMax();
			max2 = m2.removeMax();
			theSlove = max1 + max2;
			while((!m1.isEmpty() || !m2.isEmpty()) && i<k){
				System.out.println(theSlove);
				if(m1.isEmpty() && !m2.isEmpty()){
					theSlove = max1 + m2.getMax();
					mm2.put(m2.removeMax());
				} 
				if(m2.isEmpty() && !m1.isEmpty()){
					theSlove = max2 + m1.getMax();
					mm1.put(m1.removeMax());
				} 
				if (m1.isEmpty() && m2.isEmpty()){
					i++;
					break;	
				} 
				int next1 = max1 + m2.getMax();
				int next2 = max2 + m1.getMax();
				if ( next1>next2 ){
					theSlove = next1;
					int aux = m2.removeMax();
					mm2.put(aux);
				}else{
					theSlove = next2;
					int aux = m1.removeMax();
					mm1.put(aux);
				}
				i++;
			}
		}
		return theSlove;
	}
	public static void sort(LinearList<Integer> theLinear){
		int size = theLinear.size();
		Integer[] old = (Integer[]) new Integer[size];
		for (int i = 0; i < size; i++) {
			old[i] = theLinear.get(i);
		}
		Arrays.sort(old, 0, old.length);
		for(int i = size -1; i >= 0; i--)
			theLinear.remove(i);
		for (int i = 0; i < size; i++) 
			theLinear.add(i, old[size-1-i]);
	}
}
package unal.datastructures.taller2;
import java.util.*;

public class LinearListPriorityQueue<T extends Comparable<? super T>> implements MaxPriorityQueue<T>{
	LinearList<T> heap;
	int size;

	@SuppressWarnings ("unchecked")
	public LinearListPriorityQueue (int initialCapacity){
		if( initialCapacity < 1 )
         throw new IllegalArgumentException
            ( "initialCapacity must be >= 1" );
      heap = new ArrayLinearList<T>(initialCapacity+1);
      size = 0;
	}
	public LinearListPriorityQueue (){
		this (10);
	}
	public boolean isEmpty(){
		return size == 0;
	}
	public int size(){
		return size;
	}
	public T getMax(){
		return ( size == 0 ) ? null : heap.get(0);
	}
	@SuppressWarnings ("unchecked")
	public void put(T theObject){
		if(isEmpty())
			heap.add(0, theObject);
		else{
			int i = size;
			while(i > 0){
				T aux = heap.get(i-1);
				if(aux.compareTo(theObject) < 0)
					break;
				else
					i--;
			}
			heap.add(i, theObject);
		}
		size++;
	}
	public T removeMax(){
		T theRemovedElement = heap.get(0);
		heap.remove(0);
		return theRemovedElement;
	}
	@Override

   	public String toString( )
   	{
      	StringBuilder s = new StringBuilder( );
      	s.append( "The " + size + " elements are [ " );
      	if( size > 0 )
      	{  // nonempty heap
        	// do first element
        	s.append( Objects.toString( heap.get(0) ) );
         	// do remaining elements
         	for( int i = 1; i < size; i++ )
            	s.append( ", " + Objects.toString( heap.get(i) ) );
      	}
      	s.append( " ]" );
      	return new String( s );
   }
	public static void main (String[] args){
		/*LinearListPriorityQueue <Integer> a = new LinearListPriorityQueue<>();
		for (int i = 0; i < 100000; i++){
			Random r = new Random();
			int valorDado = r.nextInt(5000000);
			a.put(valorDado);
		}
		System.out.println(a);*/

		LinearListPriorityQueue<Vehicle> car1 = new LinearListPriorityQueue<>();
		MaxHeap<Vehicle> car2 = new MaxHeap<>();
		long time =	System.currentTimeMillis();
		for (int i = 0; i < 100000; i++)
			car1.put(getRandom());
		time = System.currentTimeMillis() - time;
		System.out.println("Fase 1: ");
		System.out.println("	El tiempo en nanosegundos de car1: " + time);
		time = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++)
			car2.put(getRandom());
		time = System.currentTimeMillis() - time;
		System.out.println("	El tiempo en nanosegundos de car2: " + time);
		System.out.println("Fase 2: ");
		time = System.currentTimeMillis();
		for (int i = 0; i < 50000; i++){
			car1.removeMax();
			car1.getMax();
		}
		System.out.println("	El tiempo en nanosegundos de car1: " + time);
		time = System.currentTimeMillis();
		for (int i = 0; i < 50000; i++){
			car2.removeMax();
			car2.getMax();
		}
		time = System.currentTimeMillis() - time;
		System.out.println("	El tiempo en nanosegundos de car2: " + time);

	}
	public static Vehicle getRandom(){
		Random r = new Random();
		int valorDado = r.nextInt(5000000);
		/*Creando placas aleatorias*/
		String p = getChar() + getChar() + getChar() + "-" + getNumChar() + getNumChar() + getNumChar();
		Vehicle v = new Vehicle(valorDado, p);
		return v;
	}
	public static String getChar(){
		Random l = new Random();
		/*creando numero entre 65 y 90 que es el codigo ascci del abecedario en mayusculas*/
		int aux = l.nextInt(25)+66; 
		String letra = (char)(aux) + "";
		return letra;
	}
	public static String getNumChar(){
		Random l = new Random();
		/*creando numero entre 48 y 57 que es el codigo ascci de los numeros del 0 al 9*/
		int aux = l.nextInt(9)+49; 
		String num = (char)(aux) + "";
		return num;
	}
}
class Vehicle implements Comparable<Vehicle>{
	protected int id;
	protected String plates;

	public Vehicle(){
		id = 0; plates = "N/A";
	}
	public Vehicle(int newId){
		id = newId; plates = "N/A";
	}
	public Vehicle(int newId, String newPlates){
		id = newId; plates = newPlates;
	}
	@Override
	public String toString(){
		return "(" + id + "/" + plates + ")";
	}
	@Override
	public boolean equals(Object o){
		if (o == null) return false;
		if (o == this) return true;
		if(!(o instanceof Vehicle)) return false;
		return this.id == ((Vehicle) o).id;
	}
	public int compareTo(Vehicle o){
		return this.id - o.id;
	} 
}

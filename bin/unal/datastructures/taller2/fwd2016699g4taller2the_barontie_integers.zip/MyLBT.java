package unal.datastructures.taller2;

public class MyLBT<T> extends LinkedBinaryTree<T>
{
    public T brother(T x)
    {
        ArrayQueue<BinaryTreeNode<T>> q = new ArrayQueue<>();
        BinaryTreeNode<T> aux = root;
        if(aux.element.equals(x))
            return null;
        q.put(aux);
        while(!q.isEmpty())
        {
            aux=q.getFrontElement();
            if(aux.leftChild==null || aux.rightChild==null)
                return null;
            else
                if(aux.leftChild.element.equals(x))
                    return aux.rightChild.element;
                else if (aux.rightChild.element.equals(x))
                    return aux.leftChild.element;
            q.put(aux.leftChild);
            q.put(aux.rightChild);
            q.remove();
        }
        return null;
    }
    
    public void shuffle()
    {
        ArrayStack<BinaryTreeNode<T>> s = new ArrayStack<>(),visitado=new ArrayStack<>();
        BinaryTreeNode<T> aux=root;
        T cam;
        s.push(aux);
        visitado.push(null);
        while(!s.isEmpty()&&aux!=null)
        {
            aux=s.peek();
            if(s.peek()==visitado.peek())
            {
                if(aux.leftChild!=null&&aux.rightChild!=null)
                {
                    cam=aux.leftChild.element;
                    aux.leftChild.element=aux.rightChild.element;
                    aux.rightChild.element=cam;
                }
                s.pop();
                visitado.pop();
            }
            else
            {
                if(aux.leftChild!=null||aux.rightChild!=null)
                {
                    if(aux.rightChild!=null)s.push(aux.rightChild);
                    if(aux.leftChild!=null)s.push(aux.leftChild);
                    visitado.push(aux);
                }
                else
                {
                    s.pop();
                }
            }
        }
    }
    
    @Override
    public void preOrderOutput()
    {
        ArrayStack<BinaryTreeNode<T>> s=new ArrayStack<>();
        BinaryTreeNode<T> aux=root;
        s.push(aux);
        while(!s.isEmpty()&&aux!=null)
        {
            aux=s.pop();
            System.out.print(aux.element+" ");
            if(aux.rightChild!=null)
                s.push(aux.rightChild);
            if(aux.leftChild!=null)
                s.push(aux.leftChild);
        }
    }
    
    @Override
    public void inOrderOutput()
    {
        ArrayStack<BinaryTreeNode<T>> s = new ArrayStack<>(),visitado=new ArrayStack<>();
        BinaryTreeNode<T> aux=root;
        
        s.push(aux);
        visitado.push(null);
        
        while(!s.isEmpty()&&aux!=null)
        {
            aux=s.peek();
            if(s.peek()==visitado.peek())
            {
                System.out.print(s.pop()+" ");
                visitado.pop();
                if(aux.rightChild!=null)
                    s.push(aux.rightChild);
            }
            else
            {
                if(aux.leftChild!=null)
                {
                    s.push(aux.leftChild);
                    visitado.push(aux);
                }
                else if(aux.rightChild!=null)
                {
                    System.out.print(s.pop()+" ");
                    s.push(aux.rightChild);
                }
                else
                {
                    System.out.print(s.pop()+" ");
                }
            }
        }
        
    }
    
    @Override
    public void postOrderOutput()
    {
        ArrayStack<BinaryTreeNode<T>> s = new ArrayStack<>(), visitado=new ArrayStack<>();
        BinaryTreeNode<T> aux=root;
        s.push(aux);
        visitado.push(null);
        while(!s.isEmpty()&&aux!=null)
        {
            aux=s.peek();
            if(s.peek()==visitado.peek())
            {
                System.out.print(s.pop()+" ");
                visitado.pop();
            }
            else
            {
                if(aux.leftChild!=null || aux.rightChild!=null)
                {
                    if(aux.rightChild!=null)s.push(aux.rightChild);
                    if(aux.leftChild!=null)s.push(aux.leftChild);
                    visitado.push(aux);
                }
                else
                {
                    System.out.print(s.pop()+" ");
                }
            }
        }
    }
    
    public int diametro()
    {
        return diameter(root);
    }
    
    public int diameter(BinaryTreeNode<T> aux)
    {
        if(aux==null)
            return 0;
        int lheight=height(aux.leftChild);
        int rheight=height(aux.rightChild);
        
        int ldiameter = diameter(aux.leftChild);
        int rdiameter = diameter(aux.rightChild);
        
        return max(lheight + rheight + 1, max(ldiameter, rdiameter));
        
    }
    
    int height(BinaryTreeNode<T> aux)
    {
        if(aux == null)
            return 0;
        return 1 + max(height(aux.leftChild), height(aux.rightChild));
    }
    
    int max(int a, int b)
    {
        return (a >= b)? a: b;
    }
    
    
    public static void main(String []args)
    {
        MyLBT<String> a=new MyLBT<>();
        MyLBT<String> x=new MyLBT<>();//Árbol string
        MyLBT<String> y=new MyLBT<>();
        MyLBT<String> z=new MyLBT<>();
        
        MyLBT<Integer> p = new MyLBT<>();
        MyLBT<Integer> q = new MyLBT<>();//Árbol integers
        MyLBT<Integer> r = new MyLBT<>();
        MyLBT<Integer> s = new MyLBT<>();
        MyLBT<Integer> t = new MyLBT<>();
        MyLBT<Integer> u = new MyLBT<>();

        
        x.makeTree("S",a,a);
        x.makeTree("W",x,a);
        x.makeTree("G",x,a);
        x.makeTree("U",a,x);
        x.makeTree("O",x,a);
        x.makeTree("B",x,a);
        y.makeTree("L",a,a);
        y.makeTree("D",y,a);
        y.makeTree("J",a,y);
        y.makeTree("R",a,y);
        y.makeTree("I",y,a);
        y.makeTree("H",y,x);
        x.makeTree("V",a,a);
        x.makeTree("F",x,a);
        z.makeTree("C",a,a);
        z.makeTree("N",z,x);
        x.makeTree("M",a,a);
        x.makeTree("Q",x,a);
        x.makeTree("A",z,x);
        x.makeTree("E",a,x);
        x.makeTree("T",y,x);
        
        
        q.makeTree(39,p,p);
        r.makeTree(55,p,p);
        q.makeTree(2,r,q);
        r.makeTree(15,p,p);
        q.makeTree(6,q,r);
        r.makeTree(51,p,p);
        s.makeTree(22,p,p);
        r.makeTree(69,s,r);
        s.makeTree(89,p,p);
        t.makeTree(24,p,p);
        t.makeTree(25,t,s);
        r.makeTree(5,t,r);
        q.makeTree(3,r,q);
        r.makeTree(18,p,p);
        s.makeTree(14,p,p);
        r.makeTree(30,s,r);
        s.makeTree(90,p,p);
        t.makeTree(80,p,p);
        s.makeTree(7,t,s);
        r.makeTree(4,s,r);
        q.makeTree(10,q,r);
        
        
        
        
        System.out.println("-------- String --------");
        System.out.println("Pre-Order");
        x.preOrderOutput();
        System.out.println();
        System.out.println("In-Order");
        x.inOrderOutput();
        System.out.println();
        System.out.println("Post-Order");
        x.postOrderOutput();
        System.out.println();
        System.out.println("Level-Order");
        x.levelOrderOutput();
        System.out.println();
        x.shuffle();
        System.out.println("Level-Order despues de shuffle");
        x.levelOrderOutput();
        System.out.println();
        System.out.println("Diametro del arbol de Strings");
        System.out.println(x.diametro());
        
        System.out.println("-------- Integer --------");
        System.out.println("Pre-Order");
        q.preOrderOutput();
        System.out.println();
        System.out.println("In-Order");
        q.inOrderOutput();
        System.out.println();
        System.out.println("Post-Order");
        q.postOrderOutput();
        System.out.println();
        System.out.println("Level-Order");
        q.levelOrderOutput();
        System.out.println();
        q.shuffle();
        System.out.println("Level-Order despues de shuffle");
        q.levelOrderOutput();
        System.out.println();
        System.out.println("Diametro del arbol de Strings");
        System.out.println(q.diametro());
        
        /*x.shuffle();
        x.levelOrderOutput();
        System.out.println();
        /*System.out.println(x.brother("A"));
        System.out.println(x.brother("B"));
        System.out.println(x.brother("C"));
        System.out.println(x.brother("D"));
        System.out.println(x.brother("E"));
        System.out.println(x.brother("F"));
        System.out.println(x.brother("G"));
        System.out.println(x.brother("H"));
        System.out.println(x.brother("I"));
        System.out.println(x.brother("J"));*/
    }
}
